class_name FishData
extends Resource

@export var id: StringName
@export var display_name := ""
@export var base_weight_g := 100
@export var max_weight_g := 500
@export var strength := 0.5
@export var price_per_kg := 50
@export var trophy := false
@export var baits: Array[StringName] = []
@export var activity: Dictionary = {}


func activity_at(hour: int) -> float:
	return float(activity.get(hour, 0.15))
