extends CanvasLayer

## Мобильный UI (Этап 1): виртуальный стик, кнопки заброса/подсечки/катушки,
## HUD (серебро, уровень, садок, леска), индикаторы силы заброса и натяжения.

const JoystickScript := preload("res://scripts/ui/joystick.gd")

var _player: Player
var _fishing: FishingManager
var _joystick: Control
var _hud: Label
var _status: Label
var _cast_button: Button
var _strike_button: Button
var _reel_button: Button
var _power_bar: ProgressBar
var _tension_bar: ProgressBar


func _ready() -> void:
	layer = 10
	_player = get_tree().get_first_node_in_group("player") as Player
	_fishing = get_tree().get_first_node_in_group("fishing") as FishingManager
	_build_ui()
	_fishing.state_changed.connect(_on_state_changed)
	_fishing.message_sent.connect(_on_message)
	_fishing.fight_update.connect(_on_fight_update)
	GameState.balance_changed.connect(_refresh_hud)
	GameState.keepnet_changed.connect(_refresh_hud)
	GameState.level_changed.connect(_refresh_hud)
	_on_state_changed(_fishing.state)
	_refresh_hud()


func _unhandled_input(event: InputEvent) -> void:
	if _player == null:
		return
	if event is InputEventScreenDrag:
		var w := get_viewport().get_visible_rect().size.x
		if event.position.x > w * 0.35:
			_player.handle_touch(event)
	elif event is InputEventScreenTouch:
		_player.handle_touch(event)


func _process(_delta: float) -> void:
	if _fishing.state == FishingManager.State.AIMING:
		_power_bar.value = _fishing.aim_power * 100.0


func _build_ui() -> void:
	_hud = Label.new()
	_hud.position = Vector2(16, 10)
	_hud.add_theme_font_size_override("font_size", 24)
	add_child(_hud)

	_status = Label.new()
	_status.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_status.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_status.position = Vector2(-260, 60)
	_status.size = Vector2(520, 40)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.add_theme_font_size_override("font_size", 26)
	add_child(_status)

	_joystick = JoystickScript.new()
	_joystick.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_joystick.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_joystick.size = Vector2(220, 220)
	_joystick.position = Vector2(30, -270)
	add_child(_joystick)
	_joystick.changed.connect(func(d: Vector2) -> void:
		if _player:
			_player.virtual_move = d
	)

	_cast_button = _make_button("ЗАБРОС")
	_anchor_bottom_right(_cast_button, Vector2(30, 300))
	_cast_button.button_down.connect(_fishing.begin_aim)
	_cast_button.button_up.connect(_fishing.end_aim)
	add_child(_cast_button)

	_power_bar = ProgressBar.new()
	_power_bar.custom_minimum_size = Vector2(200, 24)
	_power_bar.show_percentage = false
	_anchor_bottom_right(_power_bar, Vector2(30, 280))
	add_child(_power_bar)

	_strike_button = _make_button("ПОДСЕЧЬ!")
	_anchor_bottom_right(_strike_button, Vector2(30, 130))
	_strike_button.pressed.connect(_fishing.strike)
	add_child(_strike_button)

	_reel_button = _make_button("КАТУШКА")
	_anchor_bottom_right(_reel_button, Vector2(30, 300))
	_reel_button.button_down.connect(func() -> void: _fishing.set_reeling(true))
	_reel_button.button_up.connect(func() -> void: _fishing.set_reeling(false))
	add_child(_reel_button)

	_tension_bar = ProgressBar.new()
	_tension_bar.custom_minimum_size = Vector2(200, 24)
	_tension_bar.show_percentage = false
	_anchor_bottom_right(_tension_bar, Vector2(30, 280))
	add_child(_tension_bar)


func _make_button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(200, 130)
	b.add_theme_font_size_override("font_size", 30)
	return b


func _anchor_bottom_right(c: Control, margin: Vector2) -> void:
	c.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	c.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	c.grow_vertical = Control.GROW_DIRECTION_BEGIN
	c.position = -c.custom_minimum_size - margin


func _on_state_changed(s: FishingManager.State) -> void:
	_cast_button.visible = s in [FishingManager.State.IDLE, FishingManager.State.WAITING,
		FishingManager.State.AIMING, FishingManager.State.BITE]
	_power_bar.visible = s in [FishingManager.State.AIMING, FishingManager.State.FIGHT]
	_strike_button.visible = s == FishingManager.State.BITE
	_reel_button.visible = s == FishingManager.State.FIGHT
	_tension_bar.visible = s == FishingManager.State.FIGHT
	match s:
		FishingManager.State.IDLE:
			_on_message("Удерживайте ЗАБРОС для выбора силы, отпустите для заброса")
		FishingManager.State.WAITING:
			_on_message("Ждём поклёвку...")
		FishingManager.State.BITE:
			_on_message("!!! ПОКЛЁВКА !!!")
		FishingManager.State.FIGHT:
			_on_message("Вываживаем! Отпускайте катушку при рывках")


func _on_fight_update(tension: float, progress: float) -> void:
	var limit := maxf(0.1, float(GameState.equipment.get("line_strength", 1.0)))
	_tension_bar.value = clampf(tension / limit, 0.0, 1.0) * 100.0
	_power_bar.value = progress * 100.0


func _on_message(text: String) -> void:
	_status.text = text


func _refresh_hud() -> void:
	_hud.text = "Серебро: %d | Ур. %d (XP %d/%d) | Садок %d/%d | Леска %d%%" % [
		GameState.silver,
		GameState.level,
		GameState.xp,
		GameState.xp_to_next(),
		GameState.keepnet.size(),
		GameState.keepnet_limit,
		int(GameState.line_durability),
	]
