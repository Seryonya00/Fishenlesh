class_name VirtualJoystick
extends Control

signal changed(direction: Vector2)

const RADIUS := 110.0
const KNOB_RADIUS := 45.0

var direction := Vector2.ZERO
var _active_id := -1
var _center := Vector2.ZERO


func _ready() -> void:
	custom_minimum_size = Vector2(RADIUS, RADIUS) * 2.0
	if size.x < custom_minimum_size.x:
		size = custom_minimum_size
	_center = size * 0.5
	mouse_filter = MOUSE_FILTER_STOP
	queue_redraw()


func _draw() -> void:
	draw_circle(_center, RADIUS, Color(1, 1, 1, 0.15))
	draw_arc(_center, RADIUS, 0.0, TAU, 64, Color(1, 1, 1, 0.4), 3.0)
	draw_circle(_center + direction * (RADIUS - KNOB_RADIUS), KNOB_RADIUS, Color(1, 1, 1, 0.35))


func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and _active_id == -1:
			_active_id = event.index
			_update_knob(event.position)
		elif not event.pressed and event.index == _active_id:
			_active_id = -1
			direction = Vector2.ZERO
			changed.emit(direction)
			queue_redraw()
	elif event is InputEventScreenDrag and event.index == _active_id:
		_update_knob(event.position)


func _update_knob(pos: Vector2) -> void:
	var offset := (pos - _center).limit_length(RADIUS - KNOB_RADIUS)
	direction = offset / (RADIUS - KNOB_RADIUS)
	changed.emit(direction)
	queue_redraw()
