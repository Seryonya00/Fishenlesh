class_name Pond
extends Area3D

## Водоём "Пруд": зона заброса + глубина.
## Этап 1: плоское дно. Позже: карта глубин, течение, подводный рельеф.

@export var display_name := "Пруд"
@export var base_depth := 2.0

@onready var _shape: CollisionShape3D = $CollisionShape3D


func is_point_on_water(point: Vector3) -> bool:
	var box := _shape.shape as BoxShape3D
	if box == null:
		return false
	var local := _shape.global_transform.affine_inverse() * point
	return box.get_aabb().has_point(local)


func depth_at(_point: Vector3) -> float:
	return base_depth
