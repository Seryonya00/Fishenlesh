class_name Player
extends CharacterBody3D

const WALK_SPEED := 3.5
const RUN_SPEED := 6.5
const JUMP_VELOCITY := 4.5
const GRAVITY := 9.8
const LOOK_MOUSE := 0.0025
const LOOK_TOUCH := 0.005

var virtual_move := Vector2.ZERO
var can_move := true

var _pitch := 0.0
var _touch_look_id := -1

@onready var camera: Camera3D = $Camera3D


func _ready() -> void:
	add_to_group("player")
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_rotate_view(event.relative * LOOK_MOUSE)
	elif event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func handle_touch(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if not event.pressed and event.index == _touch_look_id:
			_touch_look_id = -1
	elif event is InputEventScreenDrag:
		if _touch_look_id == -1:
			_touch_look_id = event.index
		if event.index == _touch_look_id:
			_rotate_view(event.relative * LOOK_TOUCH)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	if can_move and Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	var dir := Vector2.ZERO
	if can_move:
		if Input.is_physical_key_pressed(KEY_W):
			dir.y -= 1
		if Input.is_physical_key_pressed(KEY_S):
			dir.y += 1
		if Input.is_physical_key_pressed(KEY_A):
			dir.x -= 1
		if Input.is_physical_key_pressed(KEY_D):
			dir.x += 1
		dir += virtual_move
		dir = dir.limit_length(1.0)

	var speed := RUN_SPEED if Input.is_physical_key_pressed(KEY_SHIFT) else WALK_SPEED
	var target := (transform.basis * Vector3(dir.x, 0.0, dir.y)) * speed
	velocity.x = target.x
	velocity.z = target.z
	move_and_slide()


func _rotate_view(delta: Vector2) -> void:
	rotate_y(-delta.x)
	_pitch = clampf(_pitch - delta.y, -1.4, 1.4)
	camera.rotation.x = _pitch
