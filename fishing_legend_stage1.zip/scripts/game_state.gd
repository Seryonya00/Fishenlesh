extends Node

signal balance_changed
signal keepnet_changed
signal level_changed

const SAVE_PATH := "user://save.cfg"

var silver := 150
var gold := 0
var xp := 0
var level := 1
var selected_bait: StringName = &"worm"
var line_durability := 100.0
var keepnet_limit := 20
var keepnet: Array = []
var owned_items: Array = [&"rod_basic"]
var equipment := {
	"rod": &"rod_basic",
	"rod_cast_bonus": 0.0,
	"line_strength": 1.0,
}


func _ready() -> void:
	load_game()


func xp_to_next() -> int:
	return 100 * level


func add_silver(amount: int) -> void:
	silver = maxi(0, silver + amount)
	balance_changed.emit()
	save_game()


func add_xp(amount: int) -> void:
	xp += amount
	var need := xp_to_next()
	while xp >= need:
		xp -= need
		level += 1
		need = xp_to_next()
		level_changed.emit()
	save_game()


func add_catch(entry: Dictionary) -> bool:
	if keepnet.size() >= keepnet_limit:
		return false
	keepnet.append(entry)
	keepnet_changed.emit()
	save_game()
	return true


func sell_all() -> int:
	var total := 0
	for e in keepnet:
		total += int(e.get("price", 0))
	keepnet.clear()
	add_silver(total)
	keepnet_changed.emit()
	save_game()
	return total


func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("player", "silver", silver)
	cfg.set_value("player", "gold", gold)
	cfg.set_value("player", "xp", xp)
	cfg.set_value("player", "level", level)
	cfg.set_value("player", "selected_bait", String(selected_bait))
	cfg.set_value("player", "line_durability", line_durability)
	cfg.set_value("player", "keepnet", keepnet)
	cfg.set_value("player", "owned_items", owned_items)
	cfg.set_value("player", "equipment", equipment)
	cfg.save(SAVE_PATH)


func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	silver = int(cfg.get_value("player", "silver", silver))
	gold = int(cfg.get_value("player", "gold", gold))
	xp = int(cfg.get_value("player", "xp", xp))
	level = int(cfg.get_value("player", "level", level))
	selected_bait = StringName(cfg.get_value("player", "selected_bait", String(selected_bait)))
	line_durability = float(cfg.get_value("player", "line_durability", line_durability))
	keepnet = cfg.get_value("player", "keepnet", keepnet)
	owned_items = cfg.get_value("player", "owned_items", owned_items)
	equipment = cfg.get_value("player", "equipment", equipment)
