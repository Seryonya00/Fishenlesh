class_name FishDB
extends RefCounted

## База рыб локации "Пруд" (Этап 1).
## Позже: отдельные списки для озера, реки, моря + сезонные коэффициенты.

static var POND: Array[FishData] = _build_pond()


static func roll(hour: int, bait: StringName) -> FishData:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var weights: Array[float] = []
	var total := 0.0
	for f in POND:
		var w := f.activity_at(hour)
		w *= 1.0 if bait in f.baits else 0.2
		if f.trophy:
			w *= 0.12
		weights.append(w)
		total += w
	if total <= 0.0:
		return null
	var pick := rng.randf() * total
	for i in POND.size():
		pick -= weights[i]
		if pick <= 0.0:
			return POND[i]
	return POND.back()


static func _f(id: StringName, fish_name: String, base_g: int, max_g: int,
		strength: float, price: int, baits: Array, trophy: bool,
		active_hours: Array) -> FishData:
	var fd := FishData.new()
	fd.id = id
	fd.display_name = fish_name
	fd.base_weight_g = base_g
	fd.max_weight_g = max_g
	fd.strength = strength
	fd.price_per_kg = price
	fd.trophy = trophy
	fd.baits = baits
	for h in active_hours:
		fd.activity[h] = 1.0
	return fd


static func _build_pond() -> Array[FishData]:
	var list: Array[FishData] = []
	# Карась — вечер и ночь, любит червя и кукурузу
	list.append(_f(&"crucian", "Карась", 150, 1200, 0.45, 60,
		[&"worm", &"corn", &"dough"], false,
		[18, 19, 20, 21, 22, 23, 0, 1, 2, 3, 4, 5]))
	# Плотва — день, мелкая, многочисленная
	list.append(_f(&"roach", "Плотва", 50, 400, 0.35, 40,
		[&"worm", &"maggot", &"dough"], false,
		[8, 9, 10, 11, 12, 13, 14, 15, 16, 17]))
	# Окунь — утро и вечер
	list.append(_f(&"perch", "Окунь", 80, 900, 0.6, 90,
		[&"worm", &"maggot", &"spinner"], false,
		[6, 7, 8, 9, 17, 18, 19, 20]))
	# Щука — сумерки, трофейная
	list.append(_f(&"pike", "Щука", 800, 6500, 1.0, 160,
		[&"livebait", &"spinner"], true,
		[5, 6, 7, 18, 19, 20, 21]))
	return list
