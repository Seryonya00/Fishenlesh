class_name Shop
extends RefCounted

## Простой магазин (Этап 1): каталог + покупка + продажа улова.
## Позже: UI каталога, прикормка, донат-валюта (золото), топовые вещи.

static var ITEMS: Array[Dictionary] = [
	{"id": &"rod_bolognese", "name": "Удилище «Болонезе» 5 м", "type": &"rod", "price": 300, "cast_bonus": 12.0, "desc": "Дальний заброс"},
	{"id": &"rod_carp", "name": "Карповое удилище 3.6 м", "type": &"rod", "price": 900, "cast_bonus": 6.0, "desc": "Запас для большой рыбы"},
	{"id": &"line_020", "name": "Леска 0.20 мм", "type": &"line", "price": 120, "strength": 1.4, "desc": "Прочнее стартовой"},
	{"id": &"line_035", "name": "Леска 0.35 мм", "type": &"line", "price": 260, "strength": 2.2, "desc": "На щуку и трофеев"},
	{"id": &"worm", "name": "Черви", "type": &"bait", "price": 5, "desc": "Универсальная наживка"},
	{"id": &"maggot", "name": "Опарыш", "type": &"bait", "price": 6, "desc": "Любят плотва и окунь"},
	{"id": &"corn", "name": "Кукуруза", "type": &"bait", "price": 4, "desc": "На карася"},
	{"id": &"dough", "name": "Тесто", "type": &"bait", "price": 2, "desc": "Дешёво и сердито"},
	{"id": &"bread", "name": "Хлеб", "type": &"bait", "price": 2, "desc": "Первый улов"},
	{"id": &"livebait", "name": "Живец", "type": &"bait", "price": 25, "desc": "На хищника"},
	{"id": &"spinner", "name": "Блёсна", "type": &"bait", "price": 150, "desc": "Оснастка на хищника"},
]


static func find_item(id: StringName) -> Dictionary:
	for it in ITEMS:
		if it["id"] == id:
			return it
	return {}


static func buy(id: StringName) -> bool:
	var item := find_item(id)
	if item.is_empty():
		return false
	if int(item.get("price", 0)) > GameState.silver:
		return false
	GameState.add_silver(-int(item["price"]))
	match String(item["type"]):
		"rod":
			GameState.equipment["rod"] = id
			GameState.equipment["rod_cast_bonus"] = float(item.get("cast_bonus", 0.0))
		"line":
			GameState.equipment["line_strength"] = float(item.get("strength", 1.0))
			GameState.line_durability = 100.0
		"bait":
			GameState.selected_bait = id
	if not (id in GameState.owned_items):
		GameState.owned_items.append(id)
	GameState.save_game()
	return true


static func sell_keepnet() -> int:
	return GameState.sell_all()
